<?php

namespace app\MyPhp\controllers;

use app\Router;

class ProductController
{
    public static function index(Router $router)
    {
        $keyword = $_GET['search'] ?? '';
        $products = $router->database->getProducts($keyword);

        return $router->renderView('products/index', [
            'products' => $products,
            'keyword' => $keyword
        ]);
    }

    public static function create(Router $router)
    {
        return $router->renderView('products/create');
    }

    public static function update(Router $router)
    {
        return $router->renderView('products/update');
    }

    public static function delete(Router $router)
    {
        $id = $_POST['id'] ?? null;

        if ($id) {
            $router->database->deleteProduct($id);
        }

        header('Location: /phpProject/public/products');
        exit;
    }

}
<?php
function randomString($n)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';
    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $str .= $characters[$index];
    }

    return $str;
}

function searchProducts($pdo, $term)
{
    $stmt = $pdo->prepare("SELECT * FROM products WHERE title LIKE :term OR description LIKE :term ORDER BY create_date DESC");
    $stmt->execute(['term' => "%$term%"]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
<?php

require_once "../functions.php";
$pdo = require_once '../database.php';

$errors = [];
$title = '';
$description = '';
$price = '';


$product = [
        'image' => ''
];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $image = $_FILES['image'] ?? null;
    $imagePath = '';

    if (!is_dir('images')) {
        mkdir('images');
    }

    if ($image && $image['tmp_name']) {
        $imagePath = 'images/' . randomString(8) . '/' . $image['name'];
        mkdir(dirname($imagePath));
        move_uploaded_file($image['tmp_name'], $imagePath);
    }

    if (!$title) $errors[] = 'Title required';
    if (!$price) $errors[] = 'Price required';

    if (empty($errors)) {
        $statement = $pdo->prepare("INSERT INTO products 
        (title, image, description, price, create_date)
        VALUES (:title, :image, :description, :price, :date)");

        $statement->execute([
                ':title' => $title,
                ':image' => $imagePath,
                ':description' => $description,
                ':price' => $price,
                ':date' => date('Y-m-d H:i:s')
        ]);

        header('Location: index.php');
    }
}
?>

<?php require_once '../view/partials/header.php'; ?>

<h1>Create Product</h1>

<div class="card">

    <?php if (!empty($errors)): ?>
        <div class="alert">
            <?php foreach ($errors as $error): ?>
                <div><?php echo $error ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>


    <form method="post" enctype="multipart/form-data">

        <div class="form-group">
            <input type="file" name="image">
        </div>

        <div class="form-group">
            <input type="text" name="title" class="form-control" placeholder="Title">
        </div>

        <div class="form-group">
            <textarea name="description" class="form-control" placeholder="Description"></textarea>
        </div>

        <div class="form-group">
            <input type="number" step=".01" name="price" class="form-control" placeholder="Price">
        </div>

        <button class="btn btn-success">Save</button>

    </form>
    <link rel="stylesheet" href="../../app.css">
</div>

</div>
</body>
</html>
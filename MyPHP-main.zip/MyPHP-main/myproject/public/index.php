<?php
require_once "../functions.php";
$pdo = require_once '../database.php';

// Search logic
$searchTerm = $_GET['search'] ?? '';

if ($searchTerm) {
    $products = searchProducts($pdo, $searchTerm);
} else {
    $statement = $pdo->prepare('SELECT * FROM products ORDER BY create_date DESC');
    $statement->execute();
    $products = $statement->fetchAll(PDO::FETCH_ASSOC);
}
?>

<?php require_once '../view/partials/header.php'; ?>

<link rel="stylesheet" href="../../app.css">

<div class="container">
    <h1>📦 Products Dashboard</h1>

    <div class="card">
        <p>
            <a href="create.php" class="btn btn-success">+ Add Product</a>
        </p>

        <!-- Search Form -->
        <form method="get" class="search-wrapper">
            <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($searchTerm); ?>">
            <button type="submit">Search</button>
        </form>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Image</th>
                <th>Title</th>
                <th>Price</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php if (count($products) === 0): ?>
                <tr><td colspan="6">No products found.</td></tr>
            <?php else: ?>
                <?php foreach ($products as $i => $product): ?>
                    <tr>
                        <td><?php echo $i + 1 ?></td>
                        <td>
                            <?php if ($product['image']): ?>
                                <img src="<?php echo $product['image'] ?>" width="60">
                            <?php endif; ?>
                        </td>
                        <td><?php echo $product['title'] ?></td>
                        <td>$<?php echo $product['price'] ?></td>
                        <td><?php echo $product['create_date'] ?></td>
                        <td>
                            <a href="../update.php?id=<?php echo $product['id'] ?>" class="btn btn-primary">Edit</a>
                            <form method="post" action="../delete.php" style="display:inline;">
                                <input type="hidden" name="id" value="<?php echo $product['id'] ?>">
                                <button type="submit" class="btn btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
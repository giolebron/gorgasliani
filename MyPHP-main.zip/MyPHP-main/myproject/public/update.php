<?php

require_once "../functions.php";
$pdo = require_once '../database.php';


$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: index.php');
    exit;
}



$statement = $pdo->prepare('SELECT * FROM products WHERE id = :id');
$statement->execute(['id' => $id]);
$product = $statement->fetch(PDO::FETCH_ASSOC);

$title = $product['title'];
$description = $product['description'];
$price = $product['price'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $image = $_FILES['image'] ?? null;
    $imagePath = $product['image'];

    if ($image && $image['tmp_name']) {
        if ($product['image']) unlink($product['image']);

        $imagePath = 'images/' . randomString(8) . '/' . $image['name'];
        mkdir(dirname($imagePath));
        move_uploaded_file($image['tmp_name'], $imagePath);
    }

    $statement = $pdo->prepare("UPDATE products 
    SET title=:title,image=:image,description=:description,price=:price 
    WHERE id=:id");

    $statement->execute([
            ':title'=>$title,
            ':image'=>$imagePath,
            ':description'=>$description,
            ':price'=>$price,
            ':id'=>$id
    ]);

    header('Location: index.php');
}
?>

<?php require_once '../view/partials/header.php'; ?>

<h1>Update Product</h1>
<link rel="stylesheet" href="../../app.css">
<div class="card">

    <form method="post" enctype="multipart/form-data">

        <?php if ($product['image']): ?>
            <img src="<?php echo $product['image'] ?>" width="80">
        <?php endif; ?>

        <div class="form-group">
            <input type="file" name="image">
        </div>

        <div class="form-group">
            <input type="text" name="title" class="form-control" value="<?php echo $title ?>">
        </div>

        <div class="form-group">
            <textarea name="description" class="form-control"><?php echo $description ?></textarea>
        </div>

        <div class="form-group">
            <input type="number" step=".01" name="price" class="form-control" value="<?php echo $price ?>">
        </div>

        <button class="btn btn-primary">Update</button>

    </form>

</div>

</div>
</body>
</html>
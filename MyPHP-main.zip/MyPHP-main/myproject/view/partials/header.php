<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products CRUD</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/MyPHP/14_product_crud/app.css?v=<?php echo time(); ?>">

</head>
<body>

<div class="container">
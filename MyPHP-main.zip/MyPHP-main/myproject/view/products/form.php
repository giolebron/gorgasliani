<form method="post" enctype="multipart/form-data">


    <?php if ($product['image']): ?>
        <img src="<?php echo $product['image'] ?>" width="80">
    <?php endif; ?>

    <div class="form-group">
        <input type="file" name="image">
    </div>

    <div class="form-group">
        <input type="text" name="title" class="form-control" value="<?php echo $title ?>">
    </div>

    <div class="form-group">
        <textarea name="description" class="form-control"><?php echo $description ?></textarea>
    </div>

    <div class="form-group">
        <input type="number" step=".01" name="price" class="form-control" value="<?php echo $price ?>">
    </div>

    <button class="btn btn-primary">Update</button>

</form>
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('projects', 'order_id')) {
            return;
        }

        Schema::table('projects', function (Blueprint $table): void {
            $table->dropUnique(['order_id']);
        });

        Schema::table('projects', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('order_id');
        });
    }

    public function down(): void
    {
        Schema::table('projects', function (Blueprint $table): void {
            $table->foreignId('order_id')
                ->nullable()
                ->constrained()
                ->nullOnDelete()
                ->unique();
        });
    }
};
